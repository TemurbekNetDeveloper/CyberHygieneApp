package com.example.individual

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class SignUpActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_up)

        // EditText va Button elementlarini topamiz
        val firstName = findViewById<EditText>(R.id.etFirstName)
        val lastName = findViewById<EditText>(R.id.etLastName)
        val email = findViewById<EditText>(R.id.etEmail)
        val password = findViewById<EditText>(R.id.etPassword)
        val btnSignUp = findViewById<Button>(R.id.btnSignUp)

        btnSignUp.setOnClickListener {
            val fname = firstName.text.toString().trim()
            val lname = lastName.text.toString().trim()
            val userEmail = email.text.toString().trim()
            val userPassword = password.text.toString().trim()

            if (fname.isNotEmpty() && lname.isNotEmpty() && userEmail.isNotEmpty() && userPassword.isNotEmpty()) {
                // MainActivity ga o‘tamiz
                val intent = Intent(this, MainActivity::class.java)
                intent.putExtra("firstName", fname) // ma'lumot uzatish ixtiyoriy
                startActivity(intent)
                finish() // SignUpActivity ni yopamiz
            } else {
                Toast.makeText(this, "Iltimos, barcha maydonlarni to‘ldiring", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
