package com.example.individual.fragments

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.example.individual.R

class ScoreFragment : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_score, container, false)
        val resultText = view.findViewById<TextView>(R.id.result_text)

        val prefs = requireActivity().getSharedPreferences("TestResult", Context.MODE_PRIVATE)
        val result = prefs.getString("result", "Natija yo‘q")
        resultText.text = result

        return view
    }
}
