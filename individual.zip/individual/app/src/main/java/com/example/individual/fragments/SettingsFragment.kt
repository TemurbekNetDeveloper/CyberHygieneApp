package com.example.individual.fragments

import android.content.Context
import android.os.Bundle
import android.widget.Button
import android.widget.Switch
import android.widget.Toast
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.individual.R

class SettingsFragment : Fragment() {

    private lateinit var switchNotifications: Switch
    private lateinit var switchDarkMode: Switch
    private lateinit var btnClearResults: Button

    private val PREFS_NAME = "AppSettings"

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_settings, container, false)

        switchNotifications = view.findViewById(R.id.switchNotifications)
        switchDarkMode = view.findViewById(R.id.switchDarkMode)
        btnClearResults = view.findViewById(R.id.btnClearResults)

        val sharedPref = requireActivity().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

        // Load saved settings
        switchNotifications.isChecked = sharedPref.getBoolean("notifications_enabled", true)
        switchDarkMode.isChecked = sharedPref.getBoolean("dark_mode_enabled", false)

        // Listeners to save preferences when toggled
        switchNotifications.setOnCheckedChangeListener { _, isChecked ->
            sharedPref.edit().putBoolean("notifications_enabled", isChecked).apply()
            Toast.makeText(requireContext(),
                if (isChecked) "Bildirishnomalar yoqildi" else "Bildirishnomalar o‘chirildi",
                Toast.LENGTH_SHORT).show()
        }

        switchDarkMode.setOnCheckedChangeListener { _, isChecked ->
            sharedPref.edit().putBoolean("dark_mode_enabled", isChecked).apply()
            Toast.makeText(requireContext(),
                if (isChecked) "Qorong‘i rejim yoqildi" else "Qorong‘i rejim o‘chirildi",
                Toast.LENGTH_SHORT).show()
            // TODO: Dark mode ni ilovaga qo'llash kodini shu yerga qo'shing
        }

        // Clear test results button
        btnClearResults.setOnClickListener {
            val testResultPref = requireActivity().getSharedPreferences("TestResult", Context.MODE_PRIVATE)
            testResultPref.edit().clear().apply()
            Toast.makeText(requireContext(), "Test natijalari tozalandi", Toast.LENGTH_SHORT).show()
        }

        return view
    }
}
