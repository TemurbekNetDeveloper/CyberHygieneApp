package com.example.individual.fragments

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.os.CountDownTimer
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import com.example.individual.R

class TestFragment : Fragment() {

    private lateinit var questionText: TextView
    private lateinit var radioGroup: RadioGroup
    private lateinit var option1: RadioButton
    private lateinit var option2: RadioButton
    private lateinit var option3: RadioButton
    private lateinit var option4: RadioButton
    private lateinit var nextButton: Button
    private lateinit var timerText: TextView
    private lateinit var restartButton: Button

    private var currentIndex = 0
    private var correctAnswers = 0
    private lateinit var questions: List<Question>
    private lateinit var timer: CountDownTimer
    private var isTestFinished = false

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_test, container, false)

        questionText = view.findViewById(R.id.question_text)
        radioGroup = view.findViewById(R.id.options_group)
        option1 = view.findViewById(R.id.option_1)
        option2 = view.findViewById(R.id.option_2)
        option3 = view.findViewById(R.id.option_3)
        option4 = view.findViewById(R.id.option_4)
        nextButton = view.findViewById(R.id.next_button)
        timerText = view.findViewById(R.id.timer_text)
        restartButton = view.findViewById(R.id.restart_button)

        questions = getQuestions()
        startTest()

        nextButton.setOnClickListener {
            if (isTestFinished) return@setOnClickListener
            val selectedId = radioGroup.checkedRadioButtonId
            if (selectedId != -1) {
                val selectedAnswer = view.findViewById<RadioButton>(selectedId).text.toString()
                if (selectedAnswer == questions[currentIndex].correctAnswer) {
                    correctAnswers++
                }
                currentIndex++
                if (currentIndex < questions.size) {
                    loadQuestion()
                } else {
                    finishTest()
                }
            } else {
                Toast.makeText(requireContext(), "Iltimos, javobni tanlang", Toast.LENGTH_SHORT).show()
            }
        }

        restartButton.setOnClickListener {
            startTest()
        }

        return view
    }

    private fun startTest() {
        currentIndex = 0
        correctAnswers = 0
        isTestFinished = false
        loadQuestion()
        restartButton.visibility = View.GONE

        timer = object : CountDownTimer(300000, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                val seconds = millisUntilFinished / 1000
                timerText.text = "Vaqt: $seconds s"
            }

            override fun onFinish() {
                finishTest()
            }
        }
        timer.start()
    }

    private fun loadQuestion() {
        radioGroup.clearCheck()
        val question = questions[currentIndex]
        questionText.text = "${currentIndex + 1}. ${question.text}"
        option1.text = question.options[0]
        option2.text = question.options[1]
        option3.text = question.options[2]
        option4.text = question.options[3]
    }

    private fun finishTest() {
        isTestFinished = true
        timer.cancel()
        restartButton.visibility = View.VISIBLE

        val grade = when {
            correctAnswers > 17 -> "A'lo"
            correctAnswers >= 13 -> "O‘rtacha"
            else -> "Havfsiz emas"
        }

        val prefs = requireActivity().getSharedPreferences("TestResult", Context.MODE_PRIVATE)
        val editor = prefs.edit()

        val fName = prefs.getString("firstName", "Foydalanuvchi")
        val lName = prefs.getString("lastName", "")
        editor.putString("result", "$fName $lName: $grade")
        editor.apply()

        Toast.makeText(requireContext(), "Natija: $grade", Toast.LENGTH_LONG).show()
    }

    private fun getQuestions(): List<Question> {
        return listOf(
            Question("1. Parolingizni har oyda o‘zgartirasizmi?",
                listOf("Ha", "Yo‘q", "Ba’zida", "Hech qachon"), "Ha"),

            Question("2. Internetda shaxsiy ma’lumotlaringizni bemalol kiritasizmi?",
                listOf("Ha", "Faqat ishonchli saytga", "Hech qachon", "Bilmadim"), "Faqat ishonchli saytga"),

            Question("3. HTTPS bilan boshlanuvchi sayt xavfsizmi?",
                listOf("Ha", "Yo‘q", "Har doim emas", "Hech narsa farq qilmaydi"), "Ha"),

            Question("4. E-mail orqali kelgan fayllarni tekshirmasdan ochasizmi?",
                listOf("Ha", "Yo‘q", "Ba’zida", "Hech qachon"), "Yo‘q"),

            Question("5. Kompyuteringizda antivirus dasturi o‘rnatilganmi?",
                listOf("Ha", "Yo‘q", "Ishlamaydi", "Bilmadim"), "Ha"),

            Question("6. Jamoat Wi-Fi tarmog‘ida banking ilovasidan foydalanasizmi?",
                listOf("Ha", "Yo‘q", "Ba’zida", "Bilmayman"), "Yo‘q"),

            Question("7. Parollarni oddiy so‘zlardan tuzasizmi?",
                listOf("Ha", "Yo‘q", "Ba’zida", "Faqat tug‘ilgan sana"), "Yo‘q"),

            Question("8. Ilova o‘rnatishda ruxsatlar (permissions)ni tekshirasizmi?",
                listOf("Ha", "Yo‘q", "Nega kerak?", "Ba’zida"), "Ha"),

            Question("9. Kompyuterga faqat kerakli dasturlarni o‘rnatasizmi?",
                listOf("Ha", "Yo‘q", "Barchasini sinab ko‘raman", "Ba’zida"), "Ha"),

            Question("10. Shubhali havolalarga bosasizmi?",
                listOf("Ha", "Yo‘q", "Ba’zida", "Agar tanish bo‘lsa"), "Yo‘q"),

            Question("11. Parollaringizda raqam, harf va belgilar aralashmasi bormi?",
                listOf("Ha", "Faqat harf", "Faqat raqam", "Faqat belgilar"), "Ha"),

            Question("12. Telefoningizda avtomatik bloklash yoqilganmi?",
                listOf("Ha", "Yo‘q", "Ba’zida", "Bilmadim"), "Ha"),

            Question("13. Notanish fleshkalarni kompyuterga ulaysizmi?",
                listOf("Ha", "Yo‘q", "Avval tekshiraman", "Hech qachon"), "Avval tekshiraman"),

            Question("14. Parollarni boshqa odamlar bilan bo‘lishasizmi?",
                listOf("Ha", "Yo‘q", "Tanishlar bilan", "Hech qachon"), "Yo‘q"),

            Question("15. Ilovani rasmiy do‘konlardan yuklab olasizmi?",
                listOf("Ha", "Yo‘q", "Boshqa saytlardan", "Ba’zida"), "Ha"),

            Question("16. Ijtimoiy tarmoqlarda barcha ma’lumotlaringizni ulashasizmi?",
                listOf("Ha", "Yo‘q", "Faqat do‘stlarim", "Ba’zida"), "Yo‘q"),

            Question("17. Ekran qulfini doimiy ishlatasizmi?",
                listOf("Ha", "Yo‘q", "Ba’zida", "Bilmadim"), "Ha"),

            Question("18. Ikkita autentifikatsiyani (2FA) ishlatasizmi?",
                listOf("Ha", "Yo‘q", "Bu nima?", "Hech qachon"), "Ha"),

            Question("19. Zaxira (backup) nusxalarini yaratib borasizmi?",
                listOf("Ha", "Yo‘q", "Ba’zida", "Kerak emas"), "Ha"),

            Question("20. Tizim yangilanishlarini muntazam o‘rnatasizmi?",
                listOf("Ha", "Yo‘q", "Ba’zida", "Faol emas"), "Ha"),
        )
    }

    data class Question(val text: String, val options: List<String>, val correctAnswer: String)
}
